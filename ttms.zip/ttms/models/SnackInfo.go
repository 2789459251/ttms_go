package models

type Snack_ struct {
	Id   uint
	Name string
	Num  int
}
