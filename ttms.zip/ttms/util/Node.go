package utils

const (
	Snack_user_favorite_set  = "Snack_user_favorite_set_" //+userid	//零食相应的收藏用户id
	User_snack_favorite_set  = "User_snack_favorite_set_" //+snackid
	Movie_user_favorite_set  = "Movie_user_favorite_set："
	User_Movie_favorite_set  = "User_Movie_favorite_set："
	Movie_ranking_sorted_set = "Movie_ranking_sorted_set"

	User_Movie_marked_set = "User_Movie_marked_set" //有序Set,用户电影评价列表
	Movie_Average_set     = "Movie_Average_set"
	Movie_Ticket_Num_set  = "Movie_Ticket_Num_set"
)
